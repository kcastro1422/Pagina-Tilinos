<?php 
include 'Conecta.php';

session_start();
$usu = $_POST['usuario'];
$pass = $_POST['password'];

$Squery = "SELECT * FROM usuarios";
$Ejec = $Conecta->query($Squery);

$stmt->bind_param("ss", $usu, $pass);
$stmt->execute();
$result = $stmt->get_result();
$cont = $result->num_rows;

if ($cont == 1) {
    header("Location:/indexmotos.php");
    exit(); 
} else {
    echo "No se encontró este usuario";
}

$stmt->close();
$conn->close();